# 第四问代码

运行：

```bash
.venv/bin/python -m src.problem4.solver
```

默认读取已认证的问题三 final 方案 `outputs/problem3/refactored/final/`，并将问题四结果写入
`outputs/problem4/`。也可通过 `--input` 和 `--output` 显式指定目录。

程序严格要求 `outputs/problem3/refactored/final/screening.json` 的 `feasible` 和
`continuity_certified` 均为 `true`，并交叉核对运输、中继排程、资源和通信审计。前置条件不满足时只写出
`outputs/problem4/status.json`，状态为“等待 Q3 最终方案”，不会把候选中继点或中断通信当作有效 Q3 输入。

通过门禁后，在运输架次访问关系及共同中继保障关系闭包形成的原子单元上，流式枚举 K=2、K=3 分区。每个 K 最多穷举 200,000 个候选；超过上限时显式失败，不输出部分最优结果。选择规则依次最小化总库存缺口、总资源数、运输飞行时间/中继服务时间/架次数的最大 CV。题面没有给定单一目标函数，因此该词典序规则是公开的建模选择，不是题面规定的唯一最优标准。

结果包括官方模板 `problem4_submission.xlsx`、模板配置 CSV、库存比较、工作量比较、服务区及任务映射、资源区间审计和 assumptions.json。资源峰值按固定 Q3 时间轴和半开区间计算；电池充电时长和库存均从源工作簿读取，能源组件充电时间及中继返航周转从 Q3 审计读取。组间箱数和质量不输出：现有 Q3 运输审计只有每架次逐箱交付数，没有货箱编号/质量到架次的映射，程序不会从服务区需求猜分配。
